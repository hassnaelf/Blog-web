import React, { Component } from "react";

class Home extends Component {
    render() {
        return ( 
            <div >
            <h1> Home Page!!</h1> 
            <p>Id Lorem reprehenderit ipsum et aliqua aliquip exercitation esse ipsum dolore eiusmod officia. Consequat anim elit proident elit aliquip quis Lorem aute laborum id aliquip. Et non tempor ex consectetur duis aliqua. Qui eu veniam ea nostrud ullamco in qui. Fugiat sunt non nostrud sunt laborum dolore dolore deserunt nulla aute ad proident. Nostrud cillum tempor laborum labore.
            </p>
            <p>
                Culpa dolor mollit incididunt pariatur velit minim ea quis ullamco voluptate irure ullamco magna. Sint est sint sint aute cillum esse laboris nostrud reprehenderit adipisicing et id aute. Sint cillum aliquip consequat magna culpa consectetur cillum proident sit. Incididunt ex voluptate adipisicing adipisicing ipsum pariatur. Elit do dolore reprehenderit commodo eu id veniam minim mollit voluptate aliqua dolor fugiat eiusmod. Est Lorem consectetur sit cillum esse ex cillum Lorem commodo duis. Aute voluptate culpa velit ullamco ut cupidatat commodo fugiat sunt do minim laborum labore dolor.
            </p>
            <p>
                In laboris nisi ut eiusmod culpa. Incididunt id laboris ex consectetur occaecat non sint occaecat enim Lorem sint. Aute minim eu cupidatat officia irure veniam. Aliqua elit ullamco aliquip tempor nulla laboris ad nulla cupidatat irure sunt voluptate in esse. Esse aute est ea commodo consectetur velit dolore voluptate anim laborum ex. Labore in reprehenderit ea consectetur id cupidatat. Ex enim sunt culpa officia labore.
            </p>
            </div>
        );
    }
}

export default Home;